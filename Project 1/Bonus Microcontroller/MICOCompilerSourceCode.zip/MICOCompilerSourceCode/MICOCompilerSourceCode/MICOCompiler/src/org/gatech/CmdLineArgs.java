package src.org.gatech;

import org.kohsuke.args4j.Option;


public class CmdLineArgs {
	
	@Option(name = "-in", usage="Sets the input .xml microcode statefile")
	public String inputName;
	
	@Option(name = "-out", usage="Sets the directory for the output binary files (defaults to pwd)")
	public String outputDir;

}
