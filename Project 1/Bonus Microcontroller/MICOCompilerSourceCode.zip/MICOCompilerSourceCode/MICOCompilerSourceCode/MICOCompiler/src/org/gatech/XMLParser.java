package src.org.gatech;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

/*
 * Written by Jeff Bernard and Michael Strain for use in Hella Umbrella and Hella Umbrella Level Editor
 */

public class XMLParser {

	// wrapper for XMLPullParser
	// makes life a lot easier
		private XmlPullParser parser;
		private int location; // location in xml file
		


		
		// create parser from file
		public XMLParser(String file)
		{
			try
			{
				XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
				parser = factory.newPullParser();
				//System.out.println(getParser());
			//	System.out.println(getParser());
				parser.setInput(this.openFileInput(file), null);
				//System.out.println(getParser());
				location = parser.getEventType();
				while (location != XmlPullParser.START_TAG)
				{
					location = parser.next();
				}
			}
			catch (XmlPullParserException e)
			{
				System.out.println("XML Parsing Exception: \n"+e);
			}
			catch (IOException e)
			{
				System.out.println("File not found: \n"+e);
			}
		}
	private FileInputStream openFileInput(String filename) 
	{
		try
		{
			//XMLFilePath = filename;
			return new FileInputStream(filename);
		}
		catch (FileNotFoundException e)
		{
			System.out.println(e);
			
		}
		return null;
	}

		// get name of next tag
		public String nextTag()
		{
			try
			{
				do
				{
					location = parser.next();
				} while (location != XmlPullParser.START_TAG && location != XmlPullParser.END_TAG && location != XmlPullParser.END_DOCUMENT);
				if (location == XmlPullParser.END_TAG)
				{
					return "end_"+parser.getName();
				}
				return parser.getName();
			}
			catch (XmlPullParserException e)
			{
				System.out.println(e);
			}
			catch (IOException e)
			{
				System.out.println(e);
			}
			return null;
		}
		// get name of current tag
		public String currentTag()
		{
			if (location == XmlPullParser.END_TAG)
			{
				return "end_"+parser.getName();
			}
		//	System.out.println(parser);
			return parser.getName();
		}
		
		// gets this attribute (or null if it doesn't exist)
		public String getAttribute(String name)
		{
			for (int i = 0; i < parser.getAttributeCount(); i++)
			{
				if (parser.getAttributeName(i).equals(name))
				{
					return parser.getAttributeValue(i);
				}
			}
			return null;
		}
		// get the attribute as an int (0 if it doesn't exist)
		public int getAttributeInt(String name)
		{
			try
			{
				return Integer.parseInt(getAttribute(name));
			}
			catch (NumberFormatException e)
			{
			}
			return 0;
		}
		// sometiems we need an float
		public float getAttributeFloat(String name)
		{
			try
			{
				return Float.parseFloat(getAttribute(name));
			}
			catch (NumberFormatException e)
			{
			}
			catch (NullPointerException e)
			{
			}
			return 0;
		}
		public XmlPullParser getParser(){
			return parser;
		}
		// EOF?
		public boolean eof()
		{
			return(location == XmlPullParser.END_DOCUMENT);
		}
		
}
