package src.org.gatech;
public class State
{
	public String toString()
	{
		return name + "->" + nextState;
	}
	
    //variables
    private String name; //name of the state, e.g. "fetch0" - note that names will be converted to lower case
    private String nextState; //name of the next state, e.g. "fetch1"
    public String onZ;

    //signal assertions
    public boolean DrREG;
    public boolean DrMEM;
    public boolean DrALU;
    public boolean DrPC;
    public boolean DrOFF;
    public boolean LdPC;
    public boolean LdIR;
    public boolean LdMAR;
    public boolean LdA;
    public boolean LdB;
    public boolean LdZ;
    public boolean WrREG;
    public boolean WrMEM;
    public boolean RegSelLo;
    public boolean RegSelHi;
    public boolean ALULo;
    public boolean ALUHi;
    public boolean chkZ;
    public boolean OPTest;
    
    //METHODS
    
    //default constructor
    public State()
    {
        name = "";
        nextState = "";
        onZ = "";
        DrREG = false;
        DrMEM = false;
        DrALU = false;
        DrPC = false;
        DrOFF = false;
        LdPC = false;
        LdIR = false;
        LdMAR = false;
        LdA = false;
        LdB = false;
        LdZ = false;
        WrREG = false;
        WrMEM = false;
        RegSelLo = false;
        RegSelHi = false;
        ALULo = false;
        ALUHi = false;
        chkZ=false;
        OPTest=false;
    }
    
    //initialization constructor
    public State(
            String name,
            String nextState,
            String onZ,
            boolean DrREG,
            boolean DrMEM,
            boolean DrALU,
            boolean DrPC,
            boolean DrOFF,
            boolean LdPC,
            boolean LdIR,
            boolean LdMAR,
            boolean LdA,
            boolean LdB,
            boolean LdZ,
            boolean WrREG,
            boolean WrMEM,
            boolean RegSelLo,
            boolean RegSelHi,
            boolean ALULo,
            boolean ALUHi)
    {
        this.name = name.toLowerCase();
        this.nextState = nextState.toLowerCase();
        this.onZ = onZ;
        this.DrREG = DrREG;
        this.DrMEM = DrMEM;
        this.DrALU = DrALU;
        this.DrPC = DrPC;
        this.DrOFF = DrOFF;
        this.LdPC = LdPC;
        this.LdIR = LdIR;
        this.LdMAR = LdMAR;
        this.LdA = LdA;
        this.LdB = LdB;
        this.LdZ = LdZ;
        this.WrREG = WrREG;
        this.WrMEM = WrMEM;
        this.RegSelLo = RegSelLo;
        this.RegSelHi = RegSelHi;
        this.ALULo = ALULo;
        this.ALUHi = ALUHi;
    }
    
    //getters/setters for name
    public String GetName()
    {
        return name;
    }
    
    public void SetName(String name)
    {
        this.name = name.toLowerCase();
    }
    
    //getters/setters for name
    public String GetNextStateName()
    {
        return nextState;
    }
    
    public void SetNextStateName(String name)
    {
        this.nextState = name.toLowerCase();

    }
    
    /*
     * Eclipse autogeneration ftw
     */
	public boolean isDrREG() {
		return DrREG;
	}

	public void setDrREG(boolean drREG) {
		DrREG = drREG;
	}

	public boolean isDrMEM() {
		return DrMEM;
	}

	public void setDrMEM(boolean drMEM) {
		DrMEM = drMEM;
	}

	public boolean isDrALU() {
		return DrALU;
	}

	public void setDrALU(boolean drALU) {
		DrALU = drALU;
	}

	public boolean isDrPC() {
		return DrPC;
	}

	public void setDrPC(boolean drPC) {
		DrPC = drPC;
	}

	public boolean isDrOFF() {
		return DrOFF;
	}

	public void setDrOFF(boolean drOFF) {
		DrOFF = drOFF;
	}

	public boolean isLdPC() {
		return LdPC;
	}

	public void setLdPC(boolean ldPC) {
		LdPC = ldPC;
	}

	public boolean isLdIR() {
		return LdIR;
	}

	public void setLdIR(boolean ldIR) {
		LdIR = ldIR;
	}

	public boolean isLdMAR() {
		return LdMAR;
	}

	public void setLdMAR(boolean ldMAR) {
		LdMAR = ldMAR;
	}

	public boolean isLdA() {
		return LdA;
	}

	public void setLdA(boolean ldA) {
		LdA = ldA;
	}

	public boolean isLdB() {
		return LdB;
	}

	public void setLdB(boolean ldB) {
		LdB = ldB;
	}

	public boolean isLdZ() {
		return LdZ;
	}

	public void setLdZ(boolean ldZ) {
		LdZ = ldZ;
	}

	public boolean isWrREG() {
		return WrREG;
	}

	public void setWrREG(boolean wrREG) {
		WrREG = wrREG;
	}

	public boolean isWrMEM() {
		return WrMEM;
	}

	public void setWrMEM(boolean wrMEM) {
		WrMEM = wrMEM;
	}

	public boolean isRegSelLo() {
		return RegSelLo;
	}

	public void setRegSelLo(boolean regSelLo) {
		RegSelLo = regSelLo;
	}

	public boolean isRegSelHi() {
		return RegSelHi;
	}

	public void setRegSelHi(boolean regSelHi) {
		RegSelHi = regSelHi;
	}

	public boolean isALULo() {
		return ALULo;
	}

	public void setALULo(boolean aLULo) {
		ALULo = aLULo;
	}

	public boolean isALUHi() {
		return ALUHi;
	}

	public void setALUHi(boolean aLUHi) {
		ALUHi = aLUHi;
	}

	public boolean isChkZ() {
		return chkZ;
	}

	public void setChkZ(boolean chkZ) {
		this.chkZ = chkZ;
	}

	public boolean isOPTest() {
		return OPTest;
	}

	public void setOPTest(boolean oPTest) {
		OPTest = oPTest;
	}

	public void setOnZ(String onZ) {
		this.onZ=onZ;
		
	}
}