package src.org.gatech;

import java.io.*;
import java.util.List;

/**
 * @author Andrew Liu, Alex Os
 *
 */
public class StringOutput
{
    public void outputSeq(String fileName, List<String> binStrings)
    {
        /* File Output Stuff */
        PrintWriter out;
        int binVal;
        String hexString;
        char[] outArr;
            
        try{
            out = new PrintWriter(new FileWriter(fileName));

            for(int i=0; i<binStrings.size(); i++) {
                //Convert Binary String to Hex String
                String lowOrder = binStrings.get(i).substring(2);
                String highOrder = binStrings.get(i).substring(0, 2);
                
                binVal = Integer.parseInt(highOrder, 2);
                hexString = Integer.toHexString(binVal);
               //Output
                outArr = hexString.toCharArray();
                for(int j=0; j<outArr.length; j++){
                    out.print(outArr[j]);
                    //System.out.print(outArr[j]); //debug output
                    if(j%2==1) {
                        out.print(" ");
                        //System.out.print(" "); //debug output
                    }
                }
                binVal = Integer.parseInt(lowOrder,2);
                hexString = Integer.toHexString(binVal);
                //Output
                outArr = hexString.toCharArray();
                for(int j=0; j<outArr.length; j++){
                    out.print(outArr[j]);
                    //System.out.print(outArr[j]); //debug output
                    if(j%2==1) {
                        out.print(" ");
                        //System.out.print(" "); //debug output
                    }
                }
                out.print(" ");
                
            }
            out.close();
        } catch(IOException e) {
            System.out.println("IOException: Please make sure you have sufficient priviledges to create/modify " + fileName + "!");
            System.exit(0);
        } catch(NumberFormatException e) {
            System.out.println("NumberFormatException: Something terrible has happened!");
            System.exit(0);
        }
    }
    
    public void mainArrToFile(String fileName, List<String> binStrings)
    {
        /* File Output Stuff */
        PrintWriter out;
        int binVal;
        String hexString;
        char[] outArr;
            
        try{
            out = new PrintWriter(new FileWriter(fileName));

            for(int i=0; i<binStrings.size(); i++) {
                //Convert Binary String to Hex String
                String lowOrder = binStrings.get(i).substring(1);
                String highOrder = binStrings.get(i).substring(0, 1);
                
                binVal = Integer.parseInt(highOrder, 2);
                hexString = Integer.toHexString(binVal);
               //Output
                outArr = hexString.toCharArray();
                for(int j=0; j<outArr.length; j++){
                    out.print(outArr[j]);
                }
                binVal = Integer.parseInt(lowOrder,2);
                hexString = Integer.toHexString(binVal);
                hexString = MICOCompiler.padAddress(hexString, 6);
                //Output
                outArr = hexString.toCharArray();
                for(int j=0; j<outArr.length; j++){
                    out.print(outArr[j]);
                }
                out.print(" ");
                
            }
            out.close();
        } catch(IOException e) {
            System.out.println("IOException: Please make sure you have sufficient priviledges to create/modify " + fileName + "!");
            System.exit(0);
        } catch(NumberFormatException e) {
            System.out.println("NumberFormatException: Something terrible has happened!");
            System.exit(0);
        }
    }
    
	public void strArrtoFile(String fileName, List<String> binStrings){
		/* File Output Stuff */
		PrintWriter out;
		int binVal;
		String hexString;
		//String fileName = "mainrom.txt";
		char[] outArr;
			
		try{
			out = new PrintWriter(new FileWriter(fileName));

			for(int i=0; i<binStrings.size(); i++) {
				//Convert Binary String to Hex String
				binVal = Integer.parseInt(binStrings.get(i),2);
				hexString = Integer.toHexString(binVal);
				
				//Output
				outArr = hexString.toCharArray();
				for(int j=0; j<outArr.length; j++){
					out.print(outArr[j]);
					//System.out.print(outArr[j]); //debug output
					if(j%2==1) {
						out.print(" ");
						//System.out.print(" "); //debug output
					}
				}
			}
			out.close();
		} catch(IOException e) {
			System.out.println("IOException: Please make sure you have sufficient priviledges to create/modify " + fileName + "!");
			System.exit(0);
		} catch(NumberFormatException e) {
			System.out.println("NumberFormatException: Something terrible has happened!");
			System.exit(0);
		}
	}
}
