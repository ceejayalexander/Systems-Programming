package src.org.gatech;

import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;

import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;

/**
 * Class containing the entry point for the microcode compiler for the LC2200
 * computer architecture. Note that this compiler produces 3 ROMS: The main
 * microcode ROM (Address: 6b, Data: 25b), the Sequencer ROM (Address: 3b, Data:
 * 6b), and the onZ ROM (Address: 1b, Data: 6b). Clarification: MICO stands for
 * "Microcode Instruction Compiler Object-oriented"
 * 
 * @author Alex Os, Ben Litowitz, Andrew Liu, Charley Shilling, Michael Strain
 * 
 */
public class MICOCompiler {
	// variables
	ArrayList<State> states;

	ArrayList<String> stateLines;
	ArrayList<String> sequencerLines;
	ArrayList<String> beqLines;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String xmlFileName = "";
		String outputDir = "";
		MICOCompiler mico = new MICOCompiler();

		/* Parse cmd line args - ARO */
		CmdLineArgs bean = new CmdLineArgs();
		CmdLineParser parser = new CmdLineParser(bean);
		try {
			parser.parseArgument(args);
			if (bean.inputName == null)
				throw new CmdLineException("Input name must be set");
			xmlFileName = bean.inputName;
			if (bean.outputDir != null)
				outputDir = bean.outputDir;
		} catch (CmdLineException e) {
			// handling of wrong arguments
			System.err.println(e.getMessage());
			parser.printUsage(System.err);
			return;
		}

		// Parse XML File
		try {
			mico.ParseXMLFile(xmlFileName);
			mico.ValidateStates();
			mico.generateAllStateLines();
			mico.generateSequencerLines();
			mico.generateBEQLines();
			String concat = "";
			for(int i = 0; i < mico.sequencerLines.size(); i++)
			{
			    concat += mico.sequencerLines.get(i);
			}
			
			mico.StringArrayToBinaryFile(outputDir);
			System.out.println("Micro code compiled successfully.");
		} catch (ParseException e) {
			// display exception message

			System.err.println(e.message);
			return;
		} catch (IOException e) {
			// TODO:file IO exception\
			System.err
					.println("Error reading input filename - check name and try again...");
			return;
		}
	}

	// Parses the XML file according to specification
	public void ParseXMLFile(String xmlFileName) throws IOException, ParseException{
		// check for invalid file name
		XMLParser parser = new XMLParser(xmlFileName);
		states = new ArrayList<State>();
		
		State currentState=null;
		boolean inMicroCode=false;
		boolean inState = false;
		
		//being parsing
		while(!parser.eof())
		{
			String tag = parser.currentTag();
			
			/*
			 * MICROCODE
			 */
			//Deal with microcode tag
			if(tag.equalsIgnoreCase("Microcode"))
			{
				inMicroCode = true;
			}else
			if(tag.equalsIgnoreCase("end_Microcode"))
			{
				inMicroCode = false;
			}else
		
				/*
				 * STATES
				 */
			// Deal with states tag
			if(tag.equalsIgnoreCase("state"))
			{
				if(!inMicroCode)
				{
					throw new ParseException("state tag found outside of microcode tag");
				}
				if(inState)
				{
					throw new ParseException("Multiple state tags before end-state tag");
				}
				inState = true;
				currentState = new State();
				
				//grab values from xml file
				String name = parser.getAttribute("name");
				String onZ = parser.getAttribute("onZ");
				//if no name attribute throw exception, else set name attribute
				if(name==null)
				{
					throw new ParseException("State did not contain a \"name\"");
				}
				currentState.SetName(name);
				
				if(onZ!=null)//is onZ specified?
				{
					if(onZ.equalsIgnoreCase("true")||onZ.equalsIgnoreCase("false"))//if a valid value of onZ set it, else throw exception
					{
					currentState.setOnZ(onZ.toLowerCase());
					}else{
						throw new ParseException("State: "+name+"'s onZ value was neither true nor false.");
					}
				}
				else//onZ not specified
				{
					currentState.setOnZ(null);
				}
			}else
			// Deal with end states tag
			if(tag.equalsIgnoreCase("end_state"))
			{
				if(!inState)//may not need this but may help with people debugging, not sure if XMLPullParser will throw anything
				{
					throw new ParseException("End state tag found before matching state tag");
				}
				inState = false;
				states.add(currentState);
				currentState=null;
			}else
			
				/*
				 * SIGNAL
				 */
			//Deal with signal tag
			if(tag.equalsIgnoreCase("signal"))
			{
				if(!inState||currentState==null)
				{
					throw new ParseException("Signal found out of state tag with attribute"+ parser.getAttribute("name"));
				}
				
				//this is going to be a long string of if statements
				/* For reference:
				 *    DrREG;
				      DrMEM;
				      DrALU;
				      DrPC;
				      DrOFF;
				      LdPC;
				      LdIR;
				      LdMAR;
				      LdA;
				      LdB;
				      LdZ;
				      WrREG;
				      WrMEM;
				      RegSelLo;
				      RegSelHi;
				      ALULo;
				      ALUHi;
				      chkZ;
				      OPTest;
				 */
				
				//get variable from XML file
				String signal = parser.getAttribute("name");
				
				if(signal.equalsIgnoreCase("DrREG"))
				{
					currentState.setDrREG(true);
				}else
				if(signal.equalsIgnoreCase("DrMEM"))
				{
					currentState.setDrMEM(true);
				}else
				if(signal.equalsIgnoreCase("DrALU"))
				{
					currentState.setDrALU(true);
				}else
				if(signal.equalsIgnoreCase("DrPC"))
				{
					currentState.setDrPC(true);
				}else
				if(signal.equalsIgnoreCase("DrOFF"))
				{
					currentState.setDrOFF(true);
				}else
				if(signal.equalsIgnoreCase("LdPC"))
				{
					currentState.setLdPC(true);
				}else
				if(signal.equalsIgnoreCase("LdIR"))
				{
					currentState.setLdIR(true);
				}else
				if(signal.equalsIgnoreCase("LdMAR"))
				{
					currentState.setLdMAR(true);
				}else
				if(signal.equalsIgnoreCase("LdA"))
				{
					currentState.setLdA(true);
				}else
				if(signal.equalsIgnoreCase("LdB"))
				{
					currentState.setLdB(true);
				}else
				if(signal.equalsIgnoreCase("LdZ"))
				{
					currentState.setLdZ(true);
				}else
				if(signal.equalsIgnoreCase("WrREG"))
				{
					currentState.setWrREG(true);
				}else
				if(signal.equalsIgnoreCase("WrMEM"))
				{
					currentState.setWrMEM(true);
				}else
				if(signal.equalsIgnoreCase("RegSelLo"))
				{
					currentState.setRegSelLo(true);
				}else
				if(signal.equalsIgnoreCase("RegSelHi"))
				{
					currentState.setRegSelHi(true);
				}else
				if(signal.equalsIgnoreCase("ALULo"))
				{
					currentState.setALULo(true);
				}else
				if(signal.equalsIgnoreCase("ALUHi"))
				{
					currentState.setALUHi(true);
				}else
				if(signal.equalsIgnoreCase("chkZ"))
				{
					currentState.setChkZ(true);
				}else
				if(signal.equalsIgnoreCase("OPTest"))
				{
					currentState.setOPTest(true);
				}//man I hope I didnt mess up anywhere in there, if anyone knows a better way t odo this let me know
				else
				{
					throw new ParseException("Unrecognized signal: "+signal+" found in state: "+currentState.GetName());
				}
				
			}else
			
			/*
			 * GOTO
			 */
			if(tag.equalsIgnoreCase("goto"))
			{
				if(!inState||currentState==null)//is tag in valid spot?
				{
					throw new ParseException("Signal found out of state tag with attribute: "+ parser.getAttribute("name"));
				}
				//get variable from xmlfile
				String nextName = parser.getAttribute("state");
				if(nextName==null)// does it actually contain a name?
				{
					throw new ParseException("Signal found without state attribute within State: "+currentState.GetName());
				}
				currentState.SetNextStateName(nextName);
			}
			parser.nextTag();
		}
	}

	// after we have parsed the xml file, validate all the states to make sure
	// there are no problems
	public void ValidateStates() throws ParseException {
		// check for the following parse exceptions:

		// missing initial states
		String requiredInitialStates[] = { "fetch0", "add0", "nand0", "addi0",
				"lw0", "sw0", "beq0", "jalr0", "halt0" };
		int it = 0;
		try {

			for (it = 0; it < requiredInitialStates.length; ++it) {
				lookupIndex(requiredInitialStates[it]);
			}
		} catch (ParseException e) {
			throw new ParseException("Missing required state: "
					+ requiredInitialStates[it]);
		}

		int onZTrueCount = 0;
		int onZFalseCount = 0;
		for (int i = 0; i < states.size(); ++i) {
			// no invalid state names, e.g. DEADBEEF0
			String validStates[] = { "fetch", "add", "nand", "addi", "lw",
					"sw", "beq", "jalr", "halt" };

			// state number too high
			int maxStates[] = { 10, // fetch
					4, // add
					4, // nand
					4, // addi
					4, // lw
					4, // sw
					9, // beq
					5, // jalr
					1 }; // halt
			String stateName = states.get(i).GetName();
			int stateNum = 0;
			boolean stateMatched = false;
			for (int k = 0; k < validStates.length; ++k) {
				if (stateName.matches(validStates[k] + "[0-9]+")) {
					try {
						/*
						stateNum = Integer.parseInt(Matcher
								.quoteReplacement(validStates[k]));
								*/
						stateMatched = true;
						stateNum = Integer.parseInt(stateName.substring(stateName.length() - 1));
						if (stateNum + 1 > maxStates[k]) {
							throw new ParseException("Too many "
									+ validStates[k] + " states");
						}
					} catch (NumberFormatException e) // this shouldn't happen,
					// but just to be safe
					{
						// invalid number format
						throw new ParseException("Invalid state name "
								+ stateName);
					}
				}
			}

			if (!stateMatched) // no valid state names were hit
			{
				throw new ParseException("Invalid state name " + stateName);
			}

			// referenced missing state (goto target)
			if(!states.get(i).GetNextStateName().equals(""))
				lookupIndex(states.get(i).GetNextStateName());

			// onZ counts
			if(states.get(i).onZ != null)
			{
				if (states.get(i).onZ.equals("true")) { //changed from (states.get(i).onZ == "true")
					onZTrueCount++;					
				} else if (states.get(i).onZ.equals("false")) { //changed from (states.get(i).onZ == "true")
					onZFalseCount++;
				}
			}
			
			// Duplicate states
			for (int j = i + 1; j < states.size(); ++j) {
				if (states.get(i).GetName().equals(states.get(j).GetName())) {
					throw new ParseException("Duplicate states found: "
							+ states.get(j).GetName());
				}
			}
		}

		// too many onZ or not enough onZ
		if (onZTrueCount != 1) {
			throw new ParseException((onZTrueCount > 1 ? "Too many "
					: "Not enough ")
					+ " states with onZ=\"true\", should be exactly 1");
		} else if (onZFalseCount != 1) {
			throw new ParseException((onZTrueCount > 1 ? "Too many "
					: "Not enough ")
					+ " states with onZ=\"false\", should be exactly 1");
		}

		// if there is no exception just return
		// there's no need to return a boolean because any problem should throw
		// an exception
	}

	public int lookupIndex(String stateName) throws ParseException {
		for (int i = 0; i < states.size(); i++) {
			if (stateName.equals(states.get(i).GetName())) { //TODO: probably needs to be .equals
				return i;
			}
		}

		throw new ParseException("Referenced Missing State");
	}

	public String generateStateLine(State state) throws ParseException {
		String line = "";
		// convert state names to indices to binary strings
		String nextState = state.GetNextStateName();
		int index = 0;
		if(!nextState.equals(""))
		    index = lookupIndex(nextState);
		line += padAddress(Integer.toBinaryString(index), 6);
		// write signal assertions to line
		line = (state.DrREG ? "1" : "0") + line; // bit 6
		line = (state.DrMEM ? "1" : "0") + line; // bit 7
		line = (state.DrALU ? "1" : "0") + line; // bit 8
		line = (state.DrPC ? "1" : "0") + line; // bit 9
		line = (state.DrOFF ? "1" : "0") + line; // bit 10
		line = (state.LdPC ? "1" : "0") + line; // bit 11
		line = (state.LdIR ? "1" : "0") + line; // bit 12
		line = (state.LdMAR ? "1" : "0") + line; // bit 13
		line = (state.LdA ? "1" : "0") + line; // bit 14
		line = (state.LdB ? "1" : "0") + line; // bit 15
		line = (state.LdZ ? "1" : "0") + line; // bit 16
		line = (state.WrREG ? "1" : "0") + line; // bit 17
		line = (state.WrMEM ? "1" : "0") + line; // bit 18
		line = (state.RegSelLo ? "1" : "0") + line; // bit 19
		line = (state.RegSelHi ? "1" : "0") + line; // bit 20
		line = (state.ALULo ? "1" : "0") + line; // bit 21
		line = (state.ALUHi ? "1" : "0") + line; // bit 22
		line = (state.OPTest ? "1" : "0") + line; // bit 23
		line = (state.chkZ ? "1" : "0") + line; //bit 24

		return line;
	}

	/**
	 * Generates the rows for the onZ Sequencer. When this function is over,
	 * beqLines will contain 2 entries, each representing a row in the ROM. The
	 * 0th row is the address in the main ROM of the instruction that has
	 * onZ="false" set. The 1st row is the address in the main ROM of the
	 * instruction that has onZ="true" set. The addresses are all padded out to
	 * 6 bits AS IT SHOULD BE.
	 */
	public void generateBEQLines() {
		beqLines = new ArrayList<String>();
		/* First, we need to find the state with the false onZ flag set */
		for (int i = 0; i < states.size(); i++) {
			if (states.get(i).onZ != null && states.get(i).onZ.equals("false")) {
				String falseLine = Integer.toBinaryString(i);
				if (falseLine.length() < 6) {
					/* We need to pad the address to zeros */
					falseLine = padAddress(falseLine, 6);
				}
				beqLines.add(falseLine);
			}
		}

		/* Next, we find the state with the true onZ flag set */
		for (int i = 0; i < states.size(); i++) {
			if (states.get(i).onZ != null && states.get(i).onZ.equals("true")) {
				String trueLine = Integer.toBinaryString(i);
				if (trueLine.length() < 6) {
					/* We need to pad the address to zeros */
					trueLine = padAddress(trueLine, 6);
				}
				beqLines.add(trueLine);
			}
		}
	}

	public static String padAddress(String address, int toPad) {
		String ret = new String(address);
		while (ret.length() < toPad) {
			ret = "0" + ret;
		}
		return ret;
	}

	public void generateSequencerLines() throws ParseException {
		sequencerLines = new ArrayList<String>();
		// ADD
		sequencerLines.add(padAddress(Integer
				.toBinaryString(lookupIndex("add0")), 6));
		// NAND
		sequencerLines.add(padAddress(Integer
				.toBinaryString(lookupIndex("nand0")), 6));
		// ADD I
		sequencerLines.add(padAddress(Integer
				.toBinaryString(lookupIndex("addi0")), 6));
		// LW
		sequencerLines.add(padAddress(Integer
				.toBinaryString(lookupIndex("lw0")), 6));
		// SW
		sequencerLines.add(padAddress(Integer
				.toBinaryString(lookupIndex("sw0")), 6));
		// BEQ
		sequencerLines.add(padAddress(Integer
				.toBinaryString(lookupIndex("beq0")), 6));
		// JALR
		sequencerLines.add(padAddress(Integer
				.toBinaryString(lookupIndex("jalr0")), 6));
		// HALT
		sequencerLines.add(padAddress(Integer
				.toBinaryString(lookupIndex("halt0")), 6));
	}

	// generates all lines for the microstate ROM
	public void generateAllStateLines() throws ParseException {
		stateLines = new ArrayList<String>();
		for (int i = 0; i < states.size(); ++i) {
			stateLines.add(generateStateLine(states.get(i)));
		}
	}

	/**
	 * Uses StringOutput to output all three ROMs to files taking into account the given output Directory
	 */
	public void StringArrayToBinaryFile(String outputDir) {
		StringOutput output = new StringOutput();
		output.mainArrToFile(outputDir + "mainrom.txt", stateLines);
		output.outputSeq(outputDir + "seqrom.txt", sequencerLines);
		output.outputSeq(outputDir + "beqrom.txt", beqLines);
	}
}